<?php 

?>
<html>
	<head>
		
		<title>
		
		</title>
		
		<style>
		
		</style>
		
		<script>
		
		</script>
	
	</head>

	<body>
		<nav>
		
		</nav>
		
		<menu>
		
		
		</menu>
	
	</body>
	
</html>