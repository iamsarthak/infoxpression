<?php


$con=mysqli_connect("localhost","techspac_infox","Rajivjha1996","techspac_infox");
	
if (!$con)
{
	echo 'error connecting to database';
}

?>