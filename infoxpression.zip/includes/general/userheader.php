<header id="navigation" class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
			</div>
			<nav class="collapse navbar-collapse" role="Navigation">
				<ul id="nav" class="nav navbar-nav nav-justified">
							<li><a href="index.php"><b>INFOX HOME</b></a></li>
							<li><a href="myevents.php">My Events</a></li>
							<li><a href="mynotifications.php">Notifications</a></li>
							<li><a href="mymessages.php">Messages</a></li>
							<li><a href="friends.php">Friends</a></li>
							<li><a href="friendrequests.php">Requests</a></li>
							<li><a href="updateprofile.php">Update Profile</a></li>
							<li><a href="logout.php">Log out</a></li>
			 </ul>
			</nav>

		</div>
	</header>