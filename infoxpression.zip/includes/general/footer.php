<footer id="footer" class="bg-one">
		<div class="container">
			<div class="row wow fadeInUp" data-wow-duration="500ms">
				<div class="col-md-3">
				<ul style="text-align:center;">
					<li><h4><a href="#">Techspace</a></h4></li>
					<li><h4><a href="#">E-Cell</a></h4></li>
					<li><h4><a href="#">IEEE</a></h4></li>
					<li><h4><a href="#">IETE</a></h4></li>
					
							
						</ul>
				</div>
				<div class="col-md-6">
					<div class="social-icon">
						<ul>
							<li><a href="https://play.google.com/store/apps/details?id=com.infox.dhruv.techfest"><i class="fa fa-android"></i></a>
							</li>
							<li><a href="https://www.facebook.com/infoxpression?_rdr"><i class="fa fa-facebook"></i></a>
							</li>
							<li>
								<h3> Guru Gobind Singh Indraprastha University <br>Sector 16C, Dwarka
									<br>infox@ipu.ac.in</h3>
							
						</ul>
					</div>
					<div class="copyright text-center">
						<!--img src="img/logo-infox.png"-->
						<br />
						<p>Copyright &copy; 2016. All Rights Reserved.</p>
					</div>
				</div>
				<div class="col-md-3">
				<ul>
					<li><h4>Contact</h4></li>
					
					<li><a href="mailto:rajivjhja1996@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i> rajivjhja1996@gmail.com</a></li>
					<li><i class="fa fa-phone" aria-hidden="true"></i>9871381106</li>
					<li>www.techspace.club</li>		
					<li></li>
						</ul>
				</div>
			</div>
		</div>
	</footer>