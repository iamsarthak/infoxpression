<!DOCTYPE html>

<html>

	<link rel="stylesheet" href="css/main.css">
        <title>Login | Signup InfoX 2016</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Dosis:100,300,400,700,900,300italic,400italic,700italic,900italic" type="text/css" media="all">
		
		
    </head>
    <body>
       
                        

<div class="container">
  <form action="action_page.php">
    <label for="fname"><h2>First Name</h2></label>
    <input type="text" id="fname" name="firstname">

    <label for="lname"><h2>Last Name</h2></label>
    <input type="text" id="lname" name="lastname">
    
    
    <label for="country"><h2>Institute</h2></label>
    <select id="country" name="country">
      <option value="australia">University of Delhi</option>
      <option value="canada">Guru Gobind singh Indraprastha University</option>
      <option value="usa">Banasthali Vidyapeeth</option>
      <option value="usa">IIT</option>
      <option value="usa">NSIT</option>     
      <option value="usa">Delhi Technology University</option>   
      <option value="usa">IGDTU (w)</option> 
      <option value="usa">IIIT-D</option>     
      <option value="usa">NIT-D</option>  
      <option value="usa">Jamia Millia Islamia</option>
      <option value="usa">NIIT</option>
      <option value="usa">Maharaja Agrasen Institute of Technology</option>               
    </select>
 	<br><br>
    <input type="submit" value="Submit"><div id="links"></div>
  </form>
</div>


                    </div>
                </div>
            
         
                
            </div>
        </div>

        
</script>

            
   </body></html>